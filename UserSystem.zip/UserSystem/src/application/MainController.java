package application; // our application package

import application.user;
import javafx.event.ActionEvent; // This is our ActionEvent class.
import javafx.fxml.FXML; // This is our FXML class.
import javafx.fxml.FXMLLoader; // This is our FXMLLoader class.
import javafx.geometry.Rectangle2D;
import javafx.scene.Parent; // This is our Parent class.
import javafx.scene.Scene; // This is our Scene class.
import javafx.scene.control.Label; // This is our Label class.
import javafx.scene.control.TextField; // This is our TextField class.
import javafx.stage.Screen;
import javafx.stage.Stage; // This is our Stage class.

public class MainController { // Our MainController class.
	@FXML
	private Label lblAuthentication; // Our label Authentication Field
	
	@FXML
	private TextField UserNameTextField; // Our UserNameTextField
	
	@FXML
	private TextField PasswordTextField; // Our PasswordTextField
         
	
        public void Login(ActionEvent e) throws Exception {
            
            String fName="";
            String lName="";
            
        communicate auth = new communicate();
        user user1 = auth.authenticate(UserNameTextField.getText(),PasswordTextField.getText());
        
        if(user1.authenticated) { 
			
                    lblAuthentication.setText("Welcome "+user1.fName+" "+user1.lName); // Displays to user that login was successful
		                                         
                    Parent root = FXMLLoader.load(getClass().getResource("/application/WidgetExpanded.fxml")); // loads main fxml class
              		    
                    Scene scene = new Scene(root);
		    
		    scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
		    
                    Main.setScene(scene, 300, 100);
		
		} else {
			
			lblAuthentication.setText("Failed"); // Displays to user that login has failed

		}
        }
        
        public void CollapseWidget() throws Exception{
        
                    Parent root = FXMLLoader.load(getClass().getResource("/application/WidgetCollapsed.fxml")); // loads main fxml class
                    			
		    Scene scene = new Scene(root);
		    
		    scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
		    
                    Main.setScene(scene, 300, 40);
            
        }
        
        public void ExpandWidget() throws Exception{
        
                    Parent root = FXMLLoader.load(getClass().getResource("/application/WidgetExpanded.fxml")); // loads main fxml class
			
		    Scene scene = new Scene(root);
		    
		    scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
		    
                    Main.setScene(scene,300, 100);
            
        }
        
        
        public void OpenTicket() throws Exception{
        
                    Parent root = FXMLLoader.load(getClass().getResource("/application/OpenTicket.fxml")); // loads main fxml class
			
		    Scene scene = new Scene(root);
		    
		    scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
		    
                    Main.setScene(scene, 300, 400);
            
        }

	
}
